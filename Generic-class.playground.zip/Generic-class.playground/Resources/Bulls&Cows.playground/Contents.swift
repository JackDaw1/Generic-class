import UIKit

//Задаем переменные
var bull = 0 //число "Быков"
var caw = 0 //число "Коров"
var addNumber = 0 //вспомогательная переменная для добавления чисел в массив
var startNumber: [Int] = [] //угадываемое число
var findNumber: [Int] = [] //вводимое число

//создаем массив из 4 неповторяющихся элементов
for i in 0...3 {
    addNumber = Int.random(in: 1...9)
    //проверка на неповторяемость
    while startNumber.contains(addNumber)
    {
        addNumber = Int.random(in: 1...9)
    }
    startNumber.append(addNumber)
}

//проверка на отсутствие повторяющихся элементов
//сортируем массив по возрастанию, сравниваем соседние элементы
let sortedStartNumber = startNumber.sorted()
for i in 0...2 {
    if sortedStartNumber[i+1]==sortedStartNumber[i]
    {
        print("Error!")
    }
}

//в качестве тестовой работы угадываемое число также создается автоматически
for i in 0...3 {
    addNumber = Int.random(in: 1...9)
    while findNumber.contains(addNumber)
    {
        addNumber = Int.random(in: 1...9)
    }
    findNumber.append(addNumber)
}

//проверка на отсутствие повторяющихся элементов
let sortedFindNumber = findNumber.sorted()
for i in 0...2 {
    if sortedFindNumber[i+1]==sortedFindNumber[i]
    {
        print("Error!")
    }
}

//если в массиве встречается два равных элемента, имеющих одинаковое положение в массиве,
//то это "бык"
for i in 0...3 {
    if startNumber[i]==findNumber[i]
    {
        bull+=1
    }
}
//если в массиве встречается два равных элемента, но имеющих разное положение в массиве,
//то это "корова"
for i in 0...3 {
    for j in 0...3 {
        if startNumber[i]==findNumber[j]
        {
            caw+=1
        }
    }
}

//пока что в переменную корова входит число быков, исправим это, удалив число быков
caw=caw-bull

print(startNumber)
print(findNumber)
if (bull==4)
{
    print("You guess!")
}
else
{
    print("Bull:", bull)
    print("Caw:", caw)
}


